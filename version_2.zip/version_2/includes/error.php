<section class="content-wrapper bounceInUp animated">
    <div class="container">
        <div class="std">
            <div class="page-not-found">
                <h2>404</h2>
                <h3><img src="images/signal.png" alt="error image">Oops! The Page you requested was not found!</h3>
                <div><a href="index.php" class="btn-home"><span>Back To Home</span></a></div>
            </div>
        </div>
    </div>
</section>