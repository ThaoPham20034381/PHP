<div class="top-offer-banner wow bounceInUp animated">
    <div class="container">
        <div class="row">
            <div class="offer-inner col-lg-12">
                <!--newsletter-wrap-->
                <div class="left">
                    <div class="col-1">
                        <div class="inner-text">
                            <h3>Nhẫn</h3>
                        </div><a href="?quanly=grid&danhmuc=1"><img src="images/nhan1.png" width="665" height="225" alt="offer banner1" style="object-fit: contain;"></a>
                    </div>
                    <div class="col mid">
                        <div class="inner-text">
                            <h3>Bông Tai</h3>
                        </div>
                        <a href="?quanly=grid&danhmuc=2"><img src="images/bongtai1.png" width="370" height="205" alt="offer banner2" style="object-fit: contain;"></a>
                    </div>
                    <div class="col last">
                        <div class="inner-text">
                            <h3>Vòng</h3>
                        </div>
                        <a href="?quanly=grid&danhmuc=3"><img src="images/vong1.png" width="280" height="205" alt="offer banner2" style="object-fit: contain;"></a>
                    </div>
                </div>
                <div class="right">
                    <div class="col">
                        <div class="inner-text">
                            <h4 style="color: black;">Top COLLECTION</h4>
                            <h3 style="color: black;">Dây Chuyền</h3>
                        </div>
                        <a href="?quanly=grid&danhmuc=4" title=""><img src="images/daychuyen1.png" width="458" height="450" alt="offer banner2" style="object-fit: contain;"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>