<div class="offer-banner-section wow bounceInUp animated">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-3 col-xs-6">
                <div class="col"><img src="images/promo-banner-img1.png" alt="offer banner1"></div>
            </div>
            <div class="col-lg-3 col-sm-3 col-xs-6">
                <div class="col"><img src="images/promo-banner-img2.png" alt="offer banner2"></div>
            </div>
            <div class="col-lg-3 col-sm-3 col-xs-6">
                <div class="col"><img src="images/promo-banner-img3.png" alt="offer banner3"></div>
            </div>
            <div class="col-lg-3 col-sm-3 col-xs-6">
                <div class="col last"><img src="images/promo-banner-img4.png" alt="offer banner4"></div>
            </div>
        </div>
    </div>
</div>