<div class="brand-logo">
    <div class="container">
        <div class="slider-items-products">
            <div id="brand-logo-slider" class="product-flexslider hidden-buttons">
                <div class="slider-items slider-width-col6">

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo1.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo2.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo3.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo4.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo5.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo6.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo1.png" alt="Image"></a> </div>
                    <!-- End Item -->

                    <!-- Item -->
                    <div class="item"><a href="#"><img src="images/b-logo4.png" alt="Image"></a> </div>
                    <!-- End Item -->

                </div>
            </div>
        </div>
    </div>
</div>