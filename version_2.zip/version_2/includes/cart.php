<?php
session_start();
include "./db/connect.php";

$khachhang_id = $_SESSION['khachhang_id'];

if (isset($_POST['themgiohang'])) {
    $tensanpham = $_POST['tensanpham'];
    $sanpham_id = $_POST['sanpham_id'];
    $hinhanh = $_POST['hinhanh'];
    $giasanpham = $_POST['giasanpham'];
    $soluong = $_POST['soluong'];

    $sql_giohang = mysqli_query($con, "INSERT INTO tbl_giohang(tensanpham, sanpham_id, giasanpham, hinhanh, soluong, khachhang_id) VALUES ('$tensanpham', '$sanpham_id', '$giasanpham', '$hinhanh', '$soluong', '$khachhang_id')");
}

if (isset($_POST['xoasanpham'])) {
    $sanpham_id_update = $_POST['sanpham_id_update'];

    mysqli_query($con, "DELETE FROM tbl_giohang WHERE khachhang_id='$khachhang_id' AND sanpham_id='$sanpham_id_update'");
}

if (isset($_POST['xoatatcasanpham'])) {
    mysqli_query($con, "DELETE FROM tbl_giohang WHERE khachhang_id='$khachhang_id'");
}

if (isset($_POST['updatesoluong'])) {
    $sanpham_id_update = $_POST['sanpham_id_update'];
    $soluong_update = $_POST['soluong_update'];

    mysqli_query($con, "UPDATE tbl_giohang SET soluong='$soluong_update' WHERE khachhang_id='$khachhang_id' AND sanpham_id='$sanpham_id_update'");
}
?>
<section class="main-container col1-layout wow bounceInUp animated">
    <div class="main container">
        <div class="col-main">
            <div class="cart">
                <div class="page-title">
                    <h2>Shopping Cart</h2>
                </div>
                <div class="table-responsive">
                    <form method="post" action="">
                        <input type="hidden" value="Vwww7itR3zQFe86m" name="form_key">
                        <fieldset>
                            <table class="data-table cart-table" id="shopping-cart-table">
                                <thead>
                                    <tr class="first last">
                                        <th rowspan="1">&nbsp;</th>
                                        <th rowspan="1"><span class="nobr">Product Name</span></th>
                                        <th colspan="1" class="a-center"><span class="nobr">Unit Price</span></th>
                                        <th class="a-center " rowspan="1">Qty</th>
                                        <th colspan="1" class="a-center">Subtotal</th>
                                        <th class="a-center" rowspan="1">&nbsp;</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr class="first last">
                                        <td class="a-right last" colspan="8"><a href="index.php" class="button btn-continue" title="Continue Shopping" type="button"><span>Continue Shopping</span></a>
                                            <button class="button btn-update" title="Update Cart" value="update_qty" name="updatesoluong" type="submit"><span>Update Cart</span></button>
                                            <button id="empty_cart_button" class="button" title="Clear Cart" value="empty_cart" name="xoatatcasanpham" type="submit"><span>Clear Cart</span></button>
                                        </td>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php
                                    $sql_select_giohang = mysqli_query($con, "SELECT * FROM tbl_giohang WHERE khachhang_id='$khachhang_id' ORDER BY giohang_id DESC");
                                    while ($row_select_giohang = mysqli_fetch_array($sql_select_giohang)) {
                                        $sanpham_id = $row_select_giohang['sanpham_id'];
                                        $hinhanh = $row_select_giohang['hinhanh'];
                                        $tensanpham = $row_select_giohang['tensanpham'];
                                        $giasanpham = $row_select_giohang['giasanpham'];
                                        $soluong = $row_select_giohang['soluong'];
                                    ?>
                                        <tr class="first odd">
                                            <td class="image"><a class="product-image" title="Sample Product" href="?quanly=chitiet&id=<?php echo $sanpham_id; ?>"><img width="60" alt="<?php echo $tensanpham; ?>" src="images/<?php echo $hinhanh; ?>"></a></td>
                                            <td>
                                                <h2 class="product-name"> <a href="?quanly=chitiet&<?php echo $sanpham_id; ?>"><?php echo $tensanpham; ?></a></h2>
                                            </td>
                                            <td class="a-center hidden-table"><span class="cart-price"> <span class="price"><?php echo $giasanpham; ?> VND</span> </span></td>
                                            <td class="a-center movewishlist"><input maxlength="12" class="input-text qty" title="Qty" size="4" value="<?php echo $soluong; ?>" name="soluong_update"></td>
                                            <td class="a-center movewishlist"><span class="cart-price"> <span class="price"><?php echo $giasanpham * $soluong; ?> VND</span> </span></td>
                                            <input type="hidden" name="sanpham_id_update" value="<?php echo $sanpham_id; ?>">
                                            <td class="a-center last"><button class="button remove-item" title="Remove item" type="submit" name="xoasanpham">Remove item</button></td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </fieldset>
                    </form>
                </div>
                <!-- BEGIN CART COLLATERALS -->
                <div class="cart-collaterals row">
                    <div class="col-sm-4">
                        <div class="shipping">
                            <h3>Estimate Shipping and Tax</h3>
                            <div class="shipping-form">
                                <form id="shipping-zip-form" method="post" action="#">
                                    <p>Enter your destination to get a shipping estimate.</p>
                                    <ul class="form-list">
                                        <li>
                                            <label class="required" for="country"><em>*</em>Country</label>
                                            <div class="input-box">
                                                <select title="Country" class="validate-select" id="country" name="country_id">
                                                    <option value="VN">Vietnam</option>
                                                    <option value="WF">Wallis and Futuna</option>
                                                    <option value="EH">Western Sahara</option>
                                                    <option value="YE">Yemen</option>
                                                    <option value="ZM">Zambia</option>
                                                    <option value="ZW">Zimbabwe</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li>
                                            <label for="region_id">State/Province</label>
                                            <div class="input-box">
                                                <select title="State/Province" name="region_id" id="region_id">
                                                    <option value="">Please select region, state or province</option>
                                                    <option value="1" title="Alabama">Alabama</option>
                                                    <option value="2" title="Alaska">Alaska</option>
                                                    <option value="3" title="American Samoa">American Samoa</option>
                                                    <option value="4" title="Arizona">Arizona</option>
                                                    <option value="5" title="Arkansas">Arkansas</option>
                                                </select>
                                                <input type="text" style="display:none;" class="input-text" title="State/Province" name="region" id="region">
                                            </div>
                                        </li>
                                        <li>
                                            <label for="postcode">Zip/Postal Code</label>
                                            <div class="input-box">
                                                <input type="text" name="estimate_postcode" id="postcode" class="input-text validate-postcode">
                                            </div>
                                        </li>
                                    </ul>
                                    <!--buttons-set11-->
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="discount">
                            <h3>Discount Codes</h3>
                            <form method="post" action="#" id="discount-coupon-form">
                                <label for="coupon_code">Enter your coupon code if you have one.</label>
                                <input type="hidden" value="0" id="remove-coupone" name="remove">
                                <input type="text" name="coupon_code" id="coupon_code" class="input-text fullwidth">
                                <button value="Apply Coupon" class="button coupon " title="Apply Coupon" type="button"><span>Apply Coupon</span></button>
                            </form>
                        </div>
                    </div>
                    <div class="totals col-sm-4">
                        <h3>Shopping Cart Total</h3>
                        <div class="inner">
                            <table class="table shopping-cart-table-total" id="shopping-cart-totals-table">

                                <tfoot>
                                    <tr>
                                        <td colspan="1" class="a-left"><strong>Grand Total</strong></td>
                                        <td class="a-right"><strong><span class="price">$77.38</span></strong></td>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <tr>
                                        <td colspan="1" class="a-left"> Subtotal </td>
                                        <td class="a-right"><span class="price">$77.38</span></td>
                                    </tr>
                                </tbody>
                            </table>
                            <ul class="checkout">
                                <li>
                                    <a href="?checkout"><button class="button btn-proceed-checkout" title="Proceed to Checkout" type="button"><span>Proceed to Checkout</span></button></a>
                                </li>
                            </ul>
                        </div>
                        <!--inner-->
                    </div>
                </div>
                <!--cart-collaterals-->
            </div>
        </div>
    </div>
</section>