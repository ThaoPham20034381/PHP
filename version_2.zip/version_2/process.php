<?php
session_start();
include "./db/connect.php";

if (isset($_POST['login'])) {
    $taikhoan = $_POST['email_login'];
    $matkhau = md5($_POST['password_login']);

    $sql_select_khachhang = mysqli_query($con, "SELECT * FROM tbl_khachhang WHERE email='$taikhoan' AND password='$matkhau' LIMIT 1");
    $count = mysqli_num_rows($sql_select_khachhang);
    $row_dangnhap = mysqli_fetch_assoc($sql_select_khachhang);

    if ($count > 0) {
        $_SESSION['name'] = $row_dangnhap['name'];
        $_SESSION['khachhang_id'] = $row_dangnhap['khachhang_id'];
        header('location: index.php');
        exit;
    } else {
        echo '<script>alert("Tài khoản mật khẩu sai")</script>';
    }
}

if (isset($_POST['register'])) {
    $name = $_POST['name_register'];
    $phone = $_POST['phone_register'];
    $email = $_POST['email_register'];
    $password = md5($_POST['password_register']);
    $note = $_POST['note_register'];
    $address = $_POST['address_register'];
    $giaohang = $_POST['giaohang_register'];

    $sql_khachhang = mysqli_query($con, "INSERT INTO tbl_khachhang(name,phone,email,address,note,giaohang,password) values ('$name','$phone','$email','$address','$note','$giaohang','$password')");
    $sql_select_khachhang = mysqli_query($con, "SELECT * FROM tbl_khachhang WHERE email='$email' LIMIT 1");
    $row_khachhang = mysqli_fetch_array($sql_select_khachhang);
    $_SESSION['name'] = $name;
    $_SESSION['khachhang_id'] = $row_khachhang['khachhang_id'];

    header('Location:index.php');
    exit;
}

if (isset($_POST['logout'])) {
    session_destroy();
    header('location: index.php');
    exit;
}

header('location: index.php');
exit;
